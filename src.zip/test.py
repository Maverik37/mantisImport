#!/usr/bin/python2.7
# coding: utf-8
##################################################### Import des librairies necessaire + num de version #####################################################
import Tkinter as tk
from library.ttk_bootstrap.style import *
import ttk

root = ttk.Window(themename="superhero")

b1 = ttk.Button(root, text="Submit", bootstyle="success")
b1.pack(side=LEFT, padx=5, pady=10)

b2 = tk.Button(root, text="Submit", bootstyle="info-outline")
b2.pack(side=LEFT, padx=5, pady=10)

root.mainloop()
#!/usr/bin/python2.7
# -*- coding: utf-8 -*-
import sys, os, subprocess, json

sys.path.append(os.path.abspath(os.path.join(os.getcwd(), os.pardir)))

from database.database_helper import *

class bcolors:
	HEADER = '\033[95m'
	OKBLUE = '\033[94m'
	OKCYAN = '\033[96m'
	OKYELLOW = '\033[33m'
	OKGREEN = '\033[92m'
	WARNING = '\033[93m' 
	FAIL = '\033[91m'
	ENDC = '\033[0m'
	BOLD = '\033[1m'
	UNDERLINE = '\033[4m'


class ConsultPart():
    def __init__(self):
        self.list_part_linux = PartLinux().get_all()
        self.list_part_mvs = PartMvs().get_all()
        self.title = "Consultation des Part"
        self.launch = True
        self.menu = """
            ######################### Menu #######################
            1) Consultation des Parts Linux
            2) Consultation des Parts MVS
            3) Ajout/Suppression/Modification
            4) Retour menu principal
        """
    def console_clear(self):
        clear = lambda: os.system('clear')
        clear()

    def display_partlinux_table(self):
        headers=("id","Contexte","PartSMI","PartRGCU","PartKMRG")
        self.list_part_linux.insert(0,headers)
        sizes = [max(map(len, column)) for column in zip(*self.list_part_linux)]
        divider = '+' + ''.join('-'*size+'--+' for size in sizes)
        lines = ['|' + ''.join(
                    ' ' + value.ljust(size) + ' |' for size, value in zip(sizes, row)
                    )
                    for row in self.list_part_linux]
        return '\n'.join([divider, lines[0], divider] + lines[1:] + [divider])
    
    def display_partmvs_table(self):
        headers=("id","Contexte","PartSMI","PartRGCU","PartKMRG")
        sizes = [max(map(len, column)) for column in zip(*self.list_part_mvs)]
        divider = '+' + ''.join('-'*size+'--+' for size in sizes)
        lines = ['|' + ''.join(
                    ' ' + value.ljust(size) + ' |' for size, value in zip(sizes, row)
                    )
                    for row in self.list_part_mvs]
        return '\n'.join([divider, lines[0], divider] + lines[1:] + [divider])

    def start(self):
        print "##########################",self.title,"######################"
        print self.menu
        res = raw_input("Choix :",)
        
        if res == "1":
            self.console_clear()
            table = self.display_partlinux_table()
            print "########################## Liste des part linux######################"
            print(table)
            ret = raw_input("Retour (y/n):",)

            if ret == "y":
                self.console_clear()
                self.start()
        elif res == "2":
            self.console_clear()
            print "########################## Liste des part MVS ######################"
            table = self.display_partmvs_table()
            print(table)
            ret = raw_input("Retour (y/n):",)

            if ret == "y":
                self.console_clear()
                self.start()

        elif res == "3":
            self.console_clear()
            print "########################## Ajout/Modification/Suppression ######################"
            choix = """
            ######################### Choix #######################
            1) Ajout / modification nouveau part linux
            2) Ajout / modification nouveau part mvs
            3) Retour menu consultation
            """
            print choix
            chx = raw_input("Choix:",)
            if chx == "1":
                print "########################## Ajout d'un nouveau part linux ######################\n"
                print "Choix Contexte :"
                
                for ctxt in Contexte().get_all():
                    print ctxt

                print "\n----------------------------------------------"

                contexte_prompt = True
                while contexte_prompt:
                    contexte = raw_input("Choix:",)
                    if contexte not in Contexte().get_all():
                        print "Contexte incorrect ou ajout d'un nouveau contexte ?"
                        add_new_contexte = raw_input("ajout nouveau contexte (y/n):",)
                        if add_new_contexte == "y":
                            contexte_prompt = False
                        else:
                            print "Veuillez renseigner un contexte correct"
                    else:
                        contexte_prompt = False
                #Other prompt
                partRGCU = raw_input("Part rgcu:",) or "NA"
                partSMI = raw_input("Part smi:",) or "NA"
                partKMRG = raw_input("Part kmrg:",) or "NA"
                    
                data = {
                    "RGCU":partRGCU,
                    "SMI":partSMI,
                    "KMRG":partKMRG
                }
                
                validate_prompt = True
                while validate_prompt:
                    validate = raw_input("Confirmation (y/n):",)
                    if validate not in ["y","n"]:
                        print "Veuillez valider svp"
                    else:
                        print "Ajout des nouveaux part"
                        try:
                            PartLinux().update_line(contexte,data)
                            validate_prompt = False
                        except Exception as e:
                            print str(e) # ACC1          | A9900023  | A9978045 | NA 
            
            elif chx == "2":
                print "########################## Ajout d'un nouveau part MVS ######################\n"
                print "Choix Contexte :"
                
                for ctxt in Contexte().get_all():
                    print ctxt

                print "\n----------------------------------------------"

                contexte_prompt = True
                while contexte_prompt:
                    contexte = raw_input("Choix:",)
                    if contexte not in Contexte().get_all():
                        print "Contexte incorrect ou ajout d'un nouveau contexte ?"
                        add_new_contexte = raw_input("ajout nouveau contexte (y/n):",)
                        if add_new_contexte == "y":
                            contexte_prompt = False
                        else:
                            print "Veuillez renseigner un contexte correct"
                    else:
                        contexte_prompt = False
                #Other prompt
                partRGCU = raw_input("Part rgcu:",) or "NA"
                partSMI = raw_input("Part smi:",) or "NA"
                partKMRG = raw_input("Part kmrg:",) or "NA"
                    
                data = {
                    "RGCU":partRGCU,
                    "SMI":partSMI,
                    "KMRG":partKMRG
                }
                
                validate_prompt = True
                while validate_prompt:
                    validate = raw_input("Confirmation (y/n):",)
                    if validate not in ["y","n"]:
                        print "Veuillez valider svp"
                    else:
                        print "Ajout des nouveaux part"
                        try:
                            PartMvs().update_line(contexte,data)
                            validate_prompt = False
                        except Exception as e:
                            print str(e) # ACC1          | A9900023  | A9978045 | NA 

            elif chx == "3":
                return False

        elif res == "4":
            self.console_clear()
            self.launch= False

class ConsultUnreferencedFiles():
    def __init__(self):
        self.list_files = UnreferencedFiles().get_all()
        chunks_tmp = self.chunk_list()
        self.chunks = []
        for x in chunks_tmp:
            x.insert(0,("id","fullname","part","repertoire","date_creation"))
            self.chunks.append(x)
        self.title = "Consultation des Fichiers en erreur"
        self.launch = True

    def console_clear(self):
        clear = lambda: os.system('clear')
        clear()

    def chunk_list(self):
        return [self.list_files[i:i + 30] for i in range(0, len(self.list_files), 30)]

    def delete_line(self,id):
        pass

    def display_files_table(self,ind):
        if self.chunks[ind]:
            sizes = [max(map(len, column)) for column in zip(*self.chunks[ind])]
            divider = '+' + ''.join('-'*size+'--+' for size in sizes)
            lines = ['|' + ''.join(
                        ' ' + value.ljust(size) + ' |' for size, value in zip(sizes, row)
                        )
                        for row in self.chunks[ind]]
            return '\n'.join([divider, lines[0], divider] + lines[1:] + [divider])
        else:
            return "no data"

    def start(self):
        # print self.display_files_table(0)
        # print("Page 1 sur",len(self.chunks))
        changing_page = True
        nb = 0
        page = 1
        while changing_page:
            self.console_clear()
            print self.title
            print self.display_files_table(nb)
            if page <= len(self.chunks):
                print "Page",page,"sur",len(self.chunks),"\n--------------------------"
            change_page = raw_input("Next (n) / Prec (p) / supprimer ligne (supp) / stop (s):",)
            print change_page
            if change_page == "n":
                print "nb=",nb
                nb = nb + 1
                page = page + 1
                self.console_clear()
                print self.title
                print self.display_files_table(nb)
                if page <= len(self.chunks):
                    print "Page",page,"sur",len(self.chunks),"\n--------------------------"
                change_page = raw_input("Next (n) / Prec (p) / supprimer ligne (supp) / stop (s):",)
            elif change_page == "p":
                nb = nb - 1
                page = page - 1
                self.console_clear()
                print self.title
                print self.display_files_table(nb)
                if page <= len(self.chunks):
                    print "Page",page,"sur",len(self.chunks),"\n--------------------------"
                change_page = raw_input("Next (n) / Prec (p) / supprimer ligne (supp) / stop (s):",)
            
            elif change_page == "supp":
                print "########### Suppression de ligne ###########\nRemarque : si plusieurs lignes a supprimer , renseigner les id séparés par des virgules"


            elif change_page == "s":
                changing_page=False



        main_return = raw_input("Retour menu principal (y/n):",)
        if main_return == "y":
            self.console_clear()
            self.launch= False

if __name__ == "__main__":
    ConsultUnreferencedFiles().start()
    
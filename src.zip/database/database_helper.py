#!/usr/bin/python2.7
# coding: utf-8
##################################################### Import des librairies necessaire + num de version #####################################################
import sqlite3,csv,os

# database = os.path.abspath(os.path.join(os.getcwd(), os.pardir))+"/database/PurgeNiv0"

# database = os.getcwd()+"/database/PurgeNiv0"
database = os.getcwd()+"/PurgeNiv0"

class Contexte():
    def __init__(self):
        self.database = database

    def get_all(self):
        sql = "SELECT nom FROM Contextes"
        connexion = sqlite3.connect(self.database)
        cursor = connexion.cursor()
        cursor.execute(sql)
        query = cursor.fetchall()
        connexion.close()
        data = []

        for x in query:
            if [0] not in data:
                data.append(x[0])

        return data
    
    def add_single_data(self,nom,mvs_contexte,env):
        sql = '''INSERT into Contextes VALUES (NULL,?,?,?)'''
        connexion = sqlite3.connect(self.database)
        cursor = connexion.cursor()
        try:
            cursor.execute(sql,(nom,mvs_contexte,env))
            connexion.commit()
            connexion.close()
        except sqlite3.Error as e:
            print e

class PartLinux():
    def __init__(self):
        self.database = database
        print database
    def get_all(self):
        sql = "SELECT cast(id as text ),contexte,smi,rgcu,kmrg FROM PartLinux"
        connexion = sqlite3.connect(self.database)
        cursor = connexion.cursor()
        cursor.execute(sql)
        data = cursor.fetchall()
        connexion.close()
        return data

    def add_single_data(self,data):
        sql = '''INSERT into PartLinux VALUES (NULL,?,?,?,?)'''
        connexion = sqlite3.connect(self.database)
        cursor = connexion.cursor()
        try:
            cursor.execute(sql,data) #(contexte,partsmi,partrgcu,partkmrg)
            connexion.commit()
            connexion.close()
        except sqlite3.Error as e:
            print e

    def update_line(self,contexte,data):
        #On récupère l'id de la ligne à modifier avec le contexte
        try:
            connexion = sqlite3.connect(self.database)
            sql_select = "SELECT id FROM PartLinux where contexte = ?"
            cursor = connexion.cursor()
            cursor.execute(sql_select,(contexte,))
            id = cursor.fetchone()
            connexion.close()
            print id[0]
            if data["RGCU"] != "NA" and data["SMI"] != "NA" and data["KMRG"] != "NA":
                connexion = sqlite3.connect(self.database)
                cursor = connexion.cursor()
                sql_update = "UPDATE PartLinux set smi = ?, rgcu = ? , kmrg = ? where id = ? "
                cursor.execute(sql_update,(data["SMI"],data["RGCU"],data["KMRG"],id[0]))
                connexion.commit()
                connexion.close()

            elif data["RGCU"] != "NA" and data["SMI"] == "NA" and data["KMRG"] == "NA":
                print(data["RGCU"])
                connexion = sqlite3.connect(self.database)
                cursor = connexion.cursor()
                sql_update = "UPDATE PartLinux set rgcu = ? where id = ?"
                cursor.execute(sql_update,(data["RGCU"],id[0],))
                connexion.commit()
                connexion.close()

            elif data["RGCU"] == "NA" and data["SMI"] != "NA" and data["KMRG"] == "NA":
                connexion = sqlite3.connect(self.database)
                cursor = connexion.cursor()
                sql_update = "UPDATE PartLinux set smi = ? where id = ? "
                cursor.execute(sql_update,(data["SMI"],id[0]))
                connexion.commit()
                connexion.close()

            elif data["RGCU"] == "NA" and data["SMI"] == "NA" and data["KMRG"] != "NA":
                connexion = sqlite3.connect(self.database)
                cursor = connexion.cursor()
                sql_update = "UPDATE PartLinux set kmrg = ? where id = ? "
                cursor.execute(sql_update,(data["KMRG"],id[0]))
                connexion.commit()
                connexion.close()

            return "Ligne modifiée / ajoutée"
        except Exception as e:
            print str(e)

class PartMvs():
    def __init__(self):
        self.database = database

    def get_all(self):
        sql = "SELECT cast(id as text ),contexte,smi,rgcu,kmrg FROM PartMvs"
        connexion = sqlite3.connect(self.database)
        cursor = connexion.cursor()
        cursor.execute(sql)
        data = cursor.fetchall()
        connexion.close()

        return data

    def add_single_data(self,contexte,partsmi,partrgcu,partkmrg):
        sql = '''INSERT into PartMvs VALUES (NULL,?,?,?,?)'''
        connexion = sqlite3.connect(self.database)
        cursor = connexion.cursor()
        try:
            cursor.execute(sql,(contexte,partsmi,partrgcu,partkmrg))
            connexion.commit()
            connexion.close()
        except sqlite3.Error as e:
            print e 

    def update_line(self,contexte,data):
        #On récupère l'id de la ligne à modifier avec le contexte
        try:
            connexion = sqlite3.connect(self.database)
            sql_select = "SELECT id FROM PartMvs where contexte = ?"
            cursor = connexion.cursor()
            cursor.execute(sql_select,(contexte,))
            id = cursor.fetchone()
            connexion.close()
            print id[0]
            if data["RGCU"] != "NA" and data["SMI"] != "NA" and data["KMRG"] != "NA":
                connexion = sqlite3.connect(self.database)
                cursor = connexion.cursor()
                sql_update = "UPDATE PartMvs set smi = ?, rgcu = ? , kmrg = ? where id = ? "
                cursor.execute(sql_update,(data["SMI"],data["RGCU"],data["KMRG"],id[0]))
                connexion.commit()
                connexion.close()

            elif data["RGCU"] != "NA" and data["SMI"] == "NA" and data["KMRG"] == "NA":
                print(data["RGCU"])
                connexion = sqlite3.connect(self.database)
                cursor = connexion.cursor()
                sql_update = "UPDATE PartMvs set rgcu = ? where id = ?"
                cursor.execute(sql_update,(data["RGCU"],id[0],))
                connexion.commit()
                connexion.close()

            elif data["RGCU"] == "NA" and data["SMI"] != "NA" and data["KMRG"] == "NA":
                connexion = sqlite3.connect(self.database)
                cursor = connexion.cursor()
                sql_update = "UPDATE PartMvs set smi = ? where id = ? "
                cursor.execute(sql_update,(data["SMI"],id[0]))
                connexion.commit()
                connexion.close()

            elif data["RGCU"] == "NA" and data["SMI"] == "NA" and data["KMRG"] != "NA":
                connexion = sqlite3.connect(self.database)
                cursor = connexion.cursor()
                sql_update = "UPDATE PartMvs set kmrg = ? where id = ? "
                cursor.execute(sql_update,(data["KMRG"],id[0]))
                connexion.commit()
                connexion.close()

            return "Ligne modifiée / ajoutée"
        except Exception as e:
            print str(e)

class UnreferencedFiles():
    def __init__(self):
        self.database = database
    
    def get_all(self):
        sql = "SELECT cast(id as text),fullname,part,repertoire,date_creation FROM UnreferencedFiles;"
        connexion = sqlite3.connect(self.database)
        cursor = connexion.cursor()
        cursor.execute(sql)
        data = cursor.fetchall()
        connexion.close()

        return data

    def add_single_data(self,liste):
        sql = '''INSERT into UnreferencedFiles VALUES (NULL,?,?,?,?)'''
        connexion = sqlite3.connect(self.database)
        cursor = connexion.cursor()
        try:
            cursor.execute(sql,liste)
            connexion.commit()
            connexion.close()
        except sqlite3.IntegrityError  as e:
            if str(e) != "column fullname is not unique":
                raise
            else:
                pass

class DatabaseHelper():

    def __init__(self):
        self.database = database
        try:
            #On récupère la liste des tables
            connexion = sqlite3.connect(self.database)
            cursor = connexion.cursor()
            cursor.execute("""SELECT name FROM sqlite_master WHERE type='table';""")
            self.tables = cursor.fetchall()
            #récupération des données de la table Contextes
            cursor.execute("""SELECT nom,mvs_contexte,env FROM Contextes;""")
            self.data_contextes = cursor.fetchall()
            #récupération des données de la table PartsLinux/PartMvs
            cursor.execute("""SELECT contexte,smi,rgcu,kmrg FROM PartMvs;""")
            raw_data_linux_part = cursor.fetchall()
            cursor.execute("""SELECT contexte,smi,rgcu,kmrg FROM PartMvs;""")
            raw_data_mvs_part = cursor.fetchall()
            cursor.execute("""SELECT fullname,part,date FROM UnreferencedPart;""")
            self.unreferenced_files = cursor.fetchall()
            connexion.close()
            self.part_data = {}
            for row in raw_data_linux_part:
                self.part_data[row[0]]={}
                self.part_data[row[0]]["Linux"]={}
                self.part_data[row[0]]["Linux"]["SMI"] = row[1]
                self.part_data[row[0]]["Linux"]["RGCU"] = row[2]
                self.part_data[row[0]]["Linux"]["KMRG"] = row[3]

            for row in raw_data_mvs_part:
                self.part_data[row[0]]["MVS"]={}
                self.part_data[row[0]]["MVS"]["SMI"] = row[1]
                self.part_data[row[0]]["MVS"]["RGCU"] = row[2]
                self.part_data[row[0]]["MVS"]["KMRG"] = row[3]
        except Exception as e :
            #print ("[ERROR]",str(e))
            pass

    def check_part(self,part):
        check_mvs = """SELECT contexte FROM PartMvs WHERE smi = ? OR rgcu=? OR kmrg = ?;"""
        check_rgcu = """SELECT contexte FROM PartLinux WHERE smi = ? OR rgcu=? OR kmrg = ?;"""
        connexion = sqlite3.connect(self.database)
        cursor = connexion.cursor()
        try:
            cursor.execute(check_rgcu,(part,part,part))
            res_rgcu = cursor.fetchall()
            cursor.execute(check_mvs,(part,part,part))
            res_mvs = cursor.fetchall()
            connexion.close()
            res = (res_rgcu,res_mvs)
            return res
        except sqlite3.Error as e:
            print "[Error] fucntion check_part",str(e)

if __name__ == "__main__":
    data = UnreferencedFiles().get_all()
    chunks_tmp = [data[i:i + 10] for i in range(0, len(data), 10)]
    chunks = []
    for x in chunks_tmp:
        x.insert(0,("id","fullname","part","repertoire","date_creation"))
        chunks.append(x)
    print chunks[0:2]
#!/usr/bin/python2.7
# coding: utf-8

def test():
    x = "rtets"
    return x
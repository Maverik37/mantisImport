#!/usr/bin/python2.7
# coding: utf-8
##################################################### Import des librairies necessaire + num de version #####################################################
import sys,os,re

# sys.path.insert(0, '/opt/livraison/scripts/PENV_GIT/JBN/PYTHON/PURGES/NIV0/')

from database.database_helper import *
from datetime import datetime as dt
from datetime import timedelta
import datetime

def get_list_files(path):

    FILES = os.listdir(path)
    LIST = []
    #on va vérifier que chacun des fichiers a bien 7 champs
    for f in FILES:
        fullname = path+f
        if os.path.isfile(fullname):
            if not re.match(".*DGE.*", f):
                fullname = path+f
                nb_champs = len(f.split('.'))
                createdate = dt.fromtimestamp(os.path.getmtime(fullname))
                if nb_champs == 7:
                    LIST.append((f,True,createdate))
                else:
                    LIST.append((f,False,createdate))
    return LIST

def get_delta_time(date):
    current_date = dt.today()
    delta = current_date - date

    if delta.days > 31 :
        return (True,delta.days)
    else:
        return False

if __name__ == "__main__":
    test="/home/webqfadmin/AlimCarriereAssureSFCImpl?wsdl.1"
    dt = datetime.fromtimestamp(os.path.getmtime(test))




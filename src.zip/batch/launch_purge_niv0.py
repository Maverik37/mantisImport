#!/usr/bin/python2.7
# coding: utf-8
##################################################### Import des librairies necessaire + num de version #####################################################
import sys

sys.path.insert(0, '/opt/livraison/scripts/PENV_GIT/JBN/PYTHON/PURGES/NIV_2/')

from database.database_helper import *
from tools import *
import os , json, sys, time, threading,re
from datetime import datetime

########################### Importation fichier de configuration ####################
config_file = "/opt/livraison/scripts/PENV_GIT/JBN/PYTHON/PURGES/NIV0/config.json"

config = json.load(open(config_file, "r"))

#On va récupérer la liste des fichiers présents dans les différents répertoires
# work_path = config["PATH"]["work"].encode('utf-8')    

WORK_FILE = get_list_files(config["PATH"]["work"].encode('utf-8'))
RECEPTION_FILE = get_list_files(config["PATH"]["reception"].encode('utf-8'))
TMP_FILES = get_list_files(config["PATH"]["tmp"].encode('utf-8'))

UNREFERENCED_FILES = []
FILES = []

#On verif si les fichiers ont un part connu
print "Verification des fichiers présents dans WORK"
for f in WORK_FILE:
    part = f[0].split('.')[0]
    verif_part = DatabaseHelper().check_part(part)
    if verif_part[0] == [] and verif_part[1] == []:
        UNREFERENCED_FILES.append((f[0],part,"Work",f[2]))
    else:
       FILES.append((f[0],part,"Work",f[2]))

print "Verification des fichiers présents dans RECEPTION"
for f in RECEPTION_FILE:
    part = f[0].split('.')[0]
    verif_part = DatabaseHelper().check_part(part)
    if verif_part[0] == [] and verif_part[1] == []:
        UNREFERENCED_FILES.append((f[0],part,"Reception",f[2]))
    else:
       FILES.append((f[0],part,"Reception",f[2]))

msg = """
Nombre de fichier dans work: %s
Nombre de fichier dans reception: %s
Nombre de fichier dans tmp: %s
Mauvais part : %s
""" % (len(WORK_FILE),len(RECEPTION_FILE),len(TMP_FILES),len(UNREFERENCED_FILES))


print msg
#On ajoute les fichiers avec un mauvais part et ou qui n'ont pas 7 champs
#multithreading pour aller plus vite
max_threads = 10
threads = []
sema = threading.Semaphore(value=max_threads)

def add_unreferenced_file(liste):
    sema.acquire()
    obj = UnreferencedFiles()
    obj.add_single_data(liste)
    sema.release()

for f in UNREFERENCED_FILES:
    thread = threading.Thread(target=add_unreferenced_file,args=(f,))
    threads.append(thread)
    thread.start()

for t in threads:
    t.join()

#Détection des fichiers de plus de 16jours
for f in FILES:
    deltafile = get_delta_time(f[3])

    if isinstance(deltafile, tuple):
        print "Fichier",f[0],"a plus de 31 jours : ",deltafile[1]
    else:
        # print "Fichier",f[0],'a moins de 16 jours'
        pass

#Partie pour la suppression des fichiers de plus de 16 jours


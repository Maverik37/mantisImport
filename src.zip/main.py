#!/usr/bin/python2.7
# coding: utf-8
##################################################### Import des librairies necessaire + num de version #####################################################

import Tkinter as tk
import sys, os, subprocess, json
from Tkinter import Menu
import ttk
#import des classe frame
from classes.classes import *
import json

import os 

cwd = os.getcwd()
config_file= cwd+"/config.ini"
sys.path.append(os.getcwd())
from database.database_helper import *

class Main():
    """
        Classe qui va afficher le menu pour consulter les informations NIV0
    """
    def __init__(self):
        self.launch = True
        self.version = "1.0.0"
        self.title = "Outils de purge NIV0"
        #Affichage des statistiques
        self.menu = """
            ######################### Menu #######################
            1) Consultation des Parts
            2) Consultation des fichiers supprimmés (Non implémenté)
            3) Consultation des fichiers erronées
            4) Consultation des statistiques (Non implémenté)
            5) Vérification des fichiers sur NIV0 (Non implémenté)
            6) Lancer manuellement la purge NIV0 (Non implémenté)
            7) Recherche de fichier NIV0 (Non implémenté)
            8) Quitter
        """

    def StartApp(self):
        while self.launch:
            print "##########################",self.title,"###################### Version",self.version
            print self.menu
            res = raw_input("Choix :",)

            if res == "8":
                self.launch = False
            else:
                if res == "1":
                    clear = lambda: os.system('clear')
                    clear()
                    consultpart = ConsultPart()
                    while consultpart.launch:
                        consultpart.start()
                
                elif res == "3":
                    clear = lambda: os.system('clear')
                    clear()
                    consultunreffile = ConsultUnreferencedFiles()
                    while consultunreffile.launch:
                        consultunreffile.start()
    

if __name__ == "__main__":
   Main().StartApp()
